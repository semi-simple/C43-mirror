This is an early version of the WP43C program for DM42. Use it at your own risk.  

Installation instructions:  
Copy the **43C_xxL2.pgm** file to the DM42 flash disk over USB.
Flash the **43C_xxL2.pgm** file just like SDKdemo.pgm (https://github.com/swissmicros/SDKdemo)
From free42 on DM42: select [shift][SETUP][5][2][4][3] WP43S.pgm [ENTER][ENTER] wait [EXIT][EXIT]  

To leave the WP43C program: in the menu [f][MODES][up] select [f][f][SYSTEM] () to return to the DMCP system.

The following image is outdated, but still useful:
http://www.cocoon-creations.com/download/IMG_0547.JPG
